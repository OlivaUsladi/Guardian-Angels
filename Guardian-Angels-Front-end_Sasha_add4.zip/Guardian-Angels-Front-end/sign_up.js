document.addEventListener("DOMContentLoaded", function() {
    const container = document.getElementById("container");
    container.classList.remove("hidden");
  });

  