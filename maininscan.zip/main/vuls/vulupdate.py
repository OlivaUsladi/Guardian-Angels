import shutil
import os
import subprocess

subprocess.call('/usr/share/nmap/scripts/vulscan/update.sh')

src = '/home/seed/Desktop/scan/main/vuls'
trg = '/usr/share/nmap/scripts/vulscan'

files=os.listdir(src)

for fname in files:
    if fname == "cve.csv" or "exploitdb.csv" or "openvas.csv" or "osvdb.csv" or "securityfocus.csv" or "securitytracker.csv" or "xforce.csv" or "scipvuldb.csv":
        shutil.copy2(os.path.join(src,fname), trg)