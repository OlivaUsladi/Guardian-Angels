from django.shortcuts import render, HttpResponse
from .models import myuploadfile
from .models import nNmap
import subprocess

def check():
    file1 = open('/home/seed/Desktop/scan/main/report.txt', 'r')
    a = 0
    for line in file1:
        if (line == "Note: Host seems down. If it is really up, but blocking our ping probes, try -Pn\n"):
            a = 1
    return a

def data(ip):
    def scan(cmd):
        rep = open('/home/seed/Desktop/scan/main/report.txt', 'w')
        subprocess.run(f'nmap {cmd} {ip} ', shell=True, stdout=rep)

        file = open('/home/seed/Desktop/scan/main/report.txt', 'a')
        file.write('<<<<<<<<<<<<<<<<<<<<<<PORTS REPORT>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n')

    result = subprocess.run(f"masscan {ip} -p 1-65535 --wait=1| grep open | awk '{{print $4}}'|cut -d '/' -f 1", shell=True, text=True, capture_output=True)
    a = result.stdout.split('\n')
    a.pop()
    A = ','.join(a)
    if A != '':
        cmd = f"-O --osscan-guess -T5 -sS --script-args vulscanshowll=1  -sV -p {A}"
    else:
        cmd = f"-O --osscan-guess -T5 -sS --script-args vulscanshowll=1  -sV"
    scan(cmd)

    if check() == 1:
        nNmap(ip=ip, state='DOWN').save()
    else:
        rep = open('/home/seed/Desktop/scan/main/string.txt', 'w')
        subprocess.call(
            "grep open /home/seed/Desktop/scan/main/report.txt|grep -wv Warning| awk '{print $1}'| cut -d '/' -f 1",
            shell=True, stdout=rep)
        with open('/home/seed/Desktop/scan/main/string.txt') as file:
            ports = [line.rstrip() for line in file]

        rep = open('/home/seed/Desktop/scan/main/string.txt', 'w')
        subprocess.call(
            "grep open /home/seed/Desktop/scan/main/report.txt|grep -wv Warning| awk '{print $1}'| cut -d '/' -f 2",
            shell=True, stdout=rep)
        with open('/home/seed/Desktop/scan/main/string.txt') as file:
            types = [line.rstrip() for line in file]

        fun("{print $2}")
        with open('/home/seed/Desktop/scan/main/string.txt') as file:
            states = [line.rstrip() for line in file]

        fun("{print $3}")
        with open('/home/seed/Desktop/scan/main/string.txt') as file:
            services = [line.rstrip() for line in file]

        fun("{print $4}")
        with open('/home/seed/Desktop/scan/main/string.txt') as file:
            versions = [line.rstrip() for line in file]


            nNmap(ip=ip, state='UP').save()
            i = 0
            while i < len(ports):
                nNmap(port=ports[i], type=types[i], state=states[i], service=services[i], version=versions[i]).save()
                i += 1


def fun(field):
    rep = open('/home/seed/Desktop/scan/main/string.txt', 'w')
    subprocess.call(f"grep open /home/seed/Desktop/scan/main/report.txt|grep -wv Warning|awk '{field}'", shell=True,
                    stdout=rep)

def index(request):
    return render(request, "myfile/normal.html")

def test(request):
    info = nNmap.objects.all()
    return render(request, "test.html", {"info": info})


def send_files(request):
    if request.method == "POST":
        name = request.POST.get("filename")
        myfile = request.FILES.getlist("uploadfoles")
        for f in myfile:
            myuploadfile(f_name=name, myfiles=f).save()

        ipath = "/home/seed/Desktop/scan/main/media/IP.txt"
        file = open(ipath, "r")

        while True:
            line = file.readline()
            if not line:
                break
            data(line)

        return HttpResponse("ok")
