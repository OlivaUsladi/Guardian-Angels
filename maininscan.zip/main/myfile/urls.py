from django.urls import path
from . import views
app_name = "fileapp"
urlpatterns = [

    path("", views.index),
    path("test", views.test),
    path("upload", views.send_files, name="uploads"),
]