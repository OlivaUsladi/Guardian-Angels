from django.db import models


class myuploadfile(models.Model):
    f_name = models.CharField(max_length=255)
    myfiles = models.FileField(upload_to="")


class BaseModel(models.Model):
    objects = models.Manager()
    class Meta:
        abstract = True

class nNmap(BaseModel):

    ip = models.CharField(max_length=100)
    port = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    state = models.CharField(max_length=255)
    service = models.CharField(max_length=255)
    version = models.CharField(max_length=255)
    reason = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.ip} \n {self.port}\n {self.type}\n {self.state} \n {self.service} \n {self.version} \n {self.reason} "



