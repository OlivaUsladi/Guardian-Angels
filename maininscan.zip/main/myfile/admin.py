from django.contrib import admin
from . models import myuploadfile
from . models import nNmap



admin.site.register(myuploadfile)
admin.site.register(nNmap)
# Register your models here.

