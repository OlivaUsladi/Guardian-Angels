import subprocess
def fun(field):
    rep = open('/home/seed/Desktop/scan/main/string.txt', 'w')
    subprocess.call(f"grep open /home/seed/Desktop/scan/main/report.txt|grep -wv Warning|awk '{{print ${field}}}'", shell=True,
                    stdout=rep)
    with open('/home/seed/Desktop/scan/main/string.txt') as file:
        a = [line.rstrip() for line in file]
    return a


arr = fun(1)

